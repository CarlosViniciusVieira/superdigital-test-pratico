﻿using Microsoft.IdentityModel.Tokens;
using SuperDigital.DomainDrivenDesign.Domain.Entities;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SuperDigital.DigitalAccount.Api.Provider
{
    public class TokenProviderOptions
    {
        public string Path { get; set; } = "/token";
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public SigningCredentials SigningCredentials { get; set; }
        public Func<IUserService, string, string, Task<User>> IdentityResolver { get; set; }
        public Func<Task<string>> NonceGenerator { get; set; } = new Func<Task<string>>(() => Task.FromResult(Guid.NewGuid().ToString()));
        public string TokenKey { get; internal set; }
        public TimeSpan Expiration { get; set; } = TimeSpan.FromMinutes(20);
    }
}
