﻿using SuperDigital.DomainDrivenDesign.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace SuperDigital.DigitalAccount.Api.Model
{
    public class ClaimModel
    {
        public ClaimModel(User user)
        {
            this.Name = user.Name;
            this.Login = user.Login;
        }

        public string Name { get; set; }
        public string Login { get; set; }

        private List<Claim> Claims { get; set; }


        public List<Claim> Get()
        {
            Claims = new List<Claim>
            {
                new Claim(nameof(this.Login), this.Login) { },
                new Claim(nameof(this.Name), this.Name) { }
            };

            return Claims;
        }

    }
}
