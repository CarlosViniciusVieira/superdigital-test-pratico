﻿using Microsoft.AspNetCore.Mvc;
using System;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using SuperDigital.DomainDrivenDesign.Infrastructure.CrossCutting;

namespace SuperDigital.DigitalAccount.Api.Controllers
{
    public class BaseController : Controller
    {

        public IActionResult Result<T>(BaseResponse<T> result)
        {
            if (result.Success)
                return Ok(new { data = result });


            return BadRequest(result);
        }
    }
}
