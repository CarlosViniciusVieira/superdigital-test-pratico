﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SuperDigital.DomainDrivenDesign.Application.Interface;
using SuperDigital.DomainDrivenDesign.Application.Models.Request;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace SuperDigital.DigitalAccount.Api.Controllers
{
    [Authorize]
    [Route("api/v1")]
    public class TransactionController : BaseController
    {
        private readonly IBankLaunchApplication _bankLaunchApplication;

        public TransactionController(IBankLaunchApplication bankLaunchApplication)
        {
            _bankLaunchApplication = bankLaunchApplication;
        }



        [HttpPost]
        [Route("bank-transfer")]
        [SwaggerResponse((int)HttpStatusCode.OK, Type = typeof(IActionResult))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.InternalServerError)]
        [SwaggerResponse((int)HttpStatusCode.NotFound)]
        public IActionResult BankTransfer([FromBody]TransactionRequest transferRequest)
        {
            return Result(_bankLaunchApplication.OperationGenerate(transferRequest));
        }
    }
}
