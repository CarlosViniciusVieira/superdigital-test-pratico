﻿using SuperDigital.DomainDrivenDesign.Infrastructure.Data.Unit_Of_Work;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Infrastructure.Data.DB
{
    public class DbManagerFactory
    {
        public IDbConnection GetConnectionSql(string connectionString)
        {
            IDbConnection connection = new SqlConnection(connectionString);

            connection.Open();

            return connection;

        }


        public IDbCommand GetCommand(UnitOfWork unitOfWork)
        {
            return unitOfWork.CreateCommand();
        }
    }
}
