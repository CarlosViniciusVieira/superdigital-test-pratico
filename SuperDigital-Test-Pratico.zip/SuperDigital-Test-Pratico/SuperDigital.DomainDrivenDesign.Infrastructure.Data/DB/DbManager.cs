﻿using Dapper;
using SuperDigital.DomainDrivenDesign.Infrastructure.Data.Unit_Of_Work;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Infrastructure.Data.DB
{
    public class DbManager
    {
        public DbManager(string connectionString)
        {
            _connectionString = connectionString;
        }


        public string _connectionString { get; private set; }

        public IDbConnection Connection { get; set; }

        public UnitOfWork UnitOfWork { get; set; }

        public IDbCommand Command { get { return new DbManagerFactory().GetCommand(UnitOfWork); } }


        public T GetFirsOrDefault<T>(string query, object queryParam = null)
        {
            try
            {
                if (UnitOfWork != null)
                    return Command.Connection.QueryFirstOrDefault<T>(query, queryParam);


                ConnectionDb();
                return Connection.QueryFirstOrDefault<T>(query, queryParam);
            }
            catch (System.Exception ex)
            {
                throw new Exception("Erro ao realizar consulta no banco de dados", ex);
            }
        }


        public long ExecuteCommand(string query, object queryParam = null, int? commandTimeout = null)
        {

            if (UnitOfWork != null)
                return Command.Connection.Execute(query, queryParam, Command.Transaction, commandTimeout);


            ConnectionDb();
            var transaction = Connection.BeginTransaction();

            try
            {

                var response = Connection.Execute(query, queryParam, transaction, commandTimeout);

                transaction.Commit();

                return response;

            }
            catch (System.Exception ex)
            {
                transaction.Rollback();

                throw ex;
            }
        }


        public object ExecuteScalar(string query, object queryParam = null)
        {

            if (UnitOfWork != null)
                return Command.Connection.ExecuteScalar(query, queryParam, Command.Transaction);

            ConnectionDb();
            var transaction = Connection.BeginTransaction();

            try
            {
                var response = Connection.ExecuteScalar(query, queryParam, transaction);

                transaction.Commit();

                return response;

            }
            catch (System.Exception ex)
            {
                transaction.Rollback();

                throw ex;
            }
        }


        private void ConnectionDb()
        {
            if (this.Connection == null)
                this.Connection = new DbManagerFactory().GetConnectionSql(_connectionString);


        }
    }
}
