﻿using SuperDigital.DomainDrivenDesign.Domain;
using SuperDigital.DomainDrivenDesign.Domain.Entities;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Repository;
using SuperDigital.DomainDrivenDesign.Infrastructure.Data.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Infrastructure.Data.Repositories
{
    public class UserRepository : IUserRepository
    {
        private DbManager db;

        public UserRepository()
        {
            var conn = ModuleConfiguration.ConnectionString;
            db = new DbManager(conn);
        }

        public User Authenticate(string login, string password)
        {
            string query = $@"SELECT * FROM  [UsersApi]
                            WHERE   Login = @login
                                    AND Password = @password
                                    AND Active = 1";

            return db.GetFirsOrDefault<User>(query, new { login, password });
        }
    }
}
