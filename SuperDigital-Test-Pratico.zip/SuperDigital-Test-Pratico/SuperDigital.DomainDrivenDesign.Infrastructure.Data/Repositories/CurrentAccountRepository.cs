﻿using SuperDigital.DomainDrivenDesign.Domain;
using SuperDigital.DomainDrivenDesign.Domain.Entities;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Repository;
using SuperDigital.DomainDrivenDesign.Infrastructure.Data.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Infrastructure.Data.Repositories
{
    public class CurrentAccountRepository : ICurrentAccountRepository
    {
        private DbManager db;
        public CurrentAccountRepository()
        {
            var conn = ModuleConfiguration.ConnectionString;
            db = new DbManager(conn);
        }

        public CurrentAccount GetCurrentAccount(long accountNumber)
        {
            return db.GetFirsOrDefault<CurrentAccount>($"SELECT * FROM [Account] WHERE AccountNumber = {accountNumber} AND Active = 1");
        }

        public void UpdateBalance(long accountNumber, decimal newBalance)
        {
            var parameter = new
            {
                accountNumber,
                newBalance,
                updated = DateTime.UtcNow
            };

            var sqlUpdate = $@"UPDATE  Account
                            SET     Balance = @newBalance,
                                    Updated = @updated
                            WHERE   AccountNumber = @accountNumber
                                    AND Active = 1";

            db.ExecuteScalar(sqlUpdate, parameter);
        }
    }
}
