﻿using SuperDigital.DomainDrivenDesign.Domain;
using SuperDigital.DomainDrivenDesign.Domain.Entities;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Repository;
using SuperDigital.DomainDrivenDesign.Infrastructure.Data.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Infrastructure.Data.Repositories
{
    public class BankLaunchRepository : IBankLaunchRepository
    {
        private DbManager db;
        public BankLaunchRepository()
        {
            var conn = ModuleConfiguration.ConnectionString;
            db = new DbManager(conn);
        }


        public void SaveTransactionBankLaunch(BankLaunch bankLaunch)
        {
            var parameter = new
            {
                bankLaunch.AccountNumberDebit,
                bankLaunch.AccountNumberCredit,
                bankLaunch.Value,
                bankLaunch.IdTransaction,
                bankLaunch.DtTransaction
            };

            var sqlInsert = $@"
                    INSERT INTO [BankLaunchLog]
                            ( AccountNumberDebit ,
                              AccountNumberCredit ,
                              Value ,
                              IdTransaction,
                              Active ,
                              Created
                            )
                    VALUES  ( @AccountNumberDebit ,
                              @AccountNumberCredit ,
                              @Value,
                              @IdTransaction,
                              1 , 
                              @DtTransaction
                            )";

            db.ExecuteScalar(sqlInsert, parameter);
        }
    }
}
