﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Infrastructure.Data.Unit_Of_Work
{
    public interface IUnitOfWork : IDisposable
    {
        IDbTransaction Transaction { get; set; }

        IDbConnection Connection { get; set; }

        IDbCommand CreateCommand();

        bool HasConnection { get; set; }

        void SaveChanges();

        void Dispose();



    }
}
