﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Infrastructure.Data.Unit_Of_Work
{
    public class UnitOfWork : IUnitOfWork
    {
        public UnitOfWork(IDbConnection connection, bool hasConnection)
        {
            Connection = connection;
            HasConnection = hasConnection;
            Transaction = connection.BeginTransaction();
        }

        public IDbTransaction Transaction { get; set; }
        public IDbConnection Connection { get; set; }
        public bool HasConnection { get; set; }

        public IDbCommand CreateCommand()
        {
            using (IDbCommand command = Connection.CreateCommand())
            {
                command.Transaction = Transaction;

                return command;
            }
        }

        public void SaveChanges()
        {
            if (Transaction == null)
                throw new Exception("Transação nula.");


            Transaction.Commit();
        }

        public void Dispose()
        {
            if (Transaction != null)
                Transaction.Rollback();

        }
    }
}
