﻿using Microsoft.Extensions.DependencyInjection;
using SuperDigital.DomainDrivenDesign.Application.Application;
using SuperDigital.DomainDrivenDesign.Application.Interface;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Repository;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Services;
using SuperDigital.DomainDrivenDesign.Domain.Services;
using SuperDigital.DomainDrivenDesign.Infrastructure.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Infrastructure.Ioc
{
    public class Injector
    {
        public static void RegisterServices(IServiceCollection services)
        {

            // Application
            services.AddTransient<IBankLaunchApplication, BankLaunchApplication>();
            services.AddTransient<IUserService, UserService>();
            //services.AddTransient<ITransactionApplication, TransactionApplication>();

            //Service
            services.AddTransient<IBankLaunchService, BankLaunchService>();
            services.AddTransient<ICurrentAccountService, CurrentAccountService>();
            services.AddTransient<IUserService, UserService>();


            //Repository
            services.AddTransient<IBankLaunchRepository, BankLaunchRepository>();
            services.AddTransient<ICurrentAccountRepository, CurrentAccountRepository>();
            services.AddTransient<IUserRepository, UserRepository>();

        }
    }
}
