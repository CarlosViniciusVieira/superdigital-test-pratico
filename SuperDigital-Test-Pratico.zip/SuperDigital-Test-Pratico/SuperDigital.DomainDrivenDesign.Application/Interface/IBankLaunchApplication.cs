﻿using SuperDigital.DomainDrivenDesign.Application.Models.Request;
using SuperDigital.DomainDrivenDesign.Application.Models.Response;
using SuperDigital.DomainDrivenDesign.Infrastructure.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Application.Interface
{
    public interface IBankLaunchApplication
    {
        BaseResponse<TransactionResponse> OperationGenerate(TransactionRequest request);
    }
}
