﻿using SuperDigital.DomainDrivenDesign.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Application.Interface
{
    public interface IUserApplication
    {
        User Authenticate(string email, string password);
    }
}
