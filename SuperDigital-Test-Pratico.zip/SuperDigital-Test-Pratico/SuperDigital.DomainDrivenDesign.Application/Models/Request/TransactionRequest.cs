﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Application.Models.Request
{
    public class TransactionRequest
    {
        public long OriginAccountNumber { get; set; }

        public long DestinationAccountNumber { get; set; }

        public decimal Value { get; set; }

    }
}
