﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Application.Models.Response
{
    public class TransactionResponse
    {
        public Guid IdTransaction { get; set; }

        public decimal BalanceAccountDebit { get; set; }

        public decimal BalanceAccountCredit { get; set; }

    }
}
