﻿using SuperDigital.DomainDrivenDesign.Application.Interface;
using SuperDigital.DomainDrivenDesign.Application.Models.Request;
using SuperDigital.DomainDrivenDesign.Application.Models.Response;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Services;
using SuperDigital.DomainDrivenDesign.Infrastructure.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Application.Application
{
    public class BankLaunchApplication : IBankLaunchApplication
    {

        private readonly IBankLaunchService _bankLaunchService;

        public BankLaunchApplication(IBankLaunchService bankLaunchService)
        {
            _bankLaunchService = bankLaunchService;
        }

        public BaseResponse<TransactionResponse> OperationGenerate(TransactionRequest request)
        {
            try
            {
                var services = new Domain.Entities.BankLaunch
                {
                    AccountNumberDebit = request.OriginAccountNumber,
                    AccountNumberCredit = request.DestinationAccountNumber,
                    Value = request.Value,
                    DtTransaction = DateTime.Now
                };


                var result = _bankLaunchService.OperationGenerate(services);


                return new BaseResponse<TransactionResponse>()
                {
                    Result = new TransactionResponse
                    {
                        IdTransaction = services.IdTransaction,
                        BalanceAccountDebit = services.BalanceAccountDebit,
                        BalanceAccountCredit = services.BalanceAccountCredit
                    },

                    Errors = services.Errors
                };
            }
            catch (Exception ex)
            {
                var response = new BaseResponse<TransactionResponse>();

                response.Errors.Add(new ErrorResponse { Code = ex.GetHashCode(), Message = ex.Message });

                return response;
            }
        }
    }
}


