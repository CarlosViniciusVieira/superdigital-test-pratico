﻿using SuperDigital.DomainDrivenDesign.Application.Interface;
using SuperDigital.DomainDrivenDesign.Domain.Entities;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Application.Application
{
    public class UserApplication : IUserApplication
    {
        private readonly IUserService _userService;

        public UserApplication(IUserService userService)
        {
            _userService = userService;
        }

        public User Authenticate(string login, string password)
        {
            return _userService.Authenticate(login, password);
        }
    }
}
