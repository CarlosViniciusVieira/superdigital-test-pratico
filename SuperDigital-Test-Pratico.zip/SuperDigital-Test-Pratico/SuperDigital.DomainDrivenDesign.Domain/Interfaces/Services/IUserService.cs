﻿using SuperDigital.DomainDrivenDesign.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain.Interfaces.Services
{
    public interface IUserService
    {
        User Authenticate(string login, string password);

    }
}
