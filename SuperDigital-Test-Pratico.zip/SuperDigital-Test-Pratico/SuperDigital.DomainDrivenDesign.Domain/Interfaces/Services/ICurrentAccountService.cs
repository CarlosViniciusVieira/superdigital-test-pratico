﻿using SuperDigital.DomainDrivenDesign.Domain.Entities;
using SuperDigital.DomainDrivenDesign.Infrastructure.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain.Interfaces.Services
{
    public interface ICurrentAccountService
    {

        CurrentAccount GetCurrentAccount(long accountNumber);

        decimal DebitGenerate(long accountNumber,  decimal value);

        decimal CreditGenerate(long accountNumber, decimal value);

        List<ErrorResponse> ValidationCurrentAccount(long accountNumberDebit, long accountNumberCredit);
    }
}
