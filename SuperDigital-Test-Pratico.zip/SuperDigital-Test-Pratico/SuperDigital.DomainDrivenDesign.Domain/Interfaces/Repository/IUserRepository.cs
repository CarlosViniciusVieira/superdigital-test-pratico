﻿using SuperDigital.DomainDrivenDesign.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain.Interfaces.Repository
{
    public interface IUserRepository
    {
        User Authenticate(string login, string password);
    }
}
