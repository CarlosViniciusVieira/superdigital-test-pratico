﻿using SuperDigital.DomainDrivenDesign.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain.Interfaces.Repository
{
    public interface ICurrentAccountRepository
    {
        CurrentAccount GetCurrentAccount(long accountNumber);

        void UpdateBalance(long accountNumber, decimal newBalance);
    }
}
