﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain.Entities
{
    public class CurrentAccount : BaseEntity
    {
        public long AccountNumber { get; set; }

        public long Balance { get; set; }

    }
}
