﻿using SuperDigital.DomainDrivenDesign.Domain.Services.Validators;
using System;
using System.Collections.Generic;
using System.Text;


namespace SuperDigital.DomainDrivenDesign.Domain.Entities
{
    public class BankLaunch : BaseEntity
    {

        public Guid IdTransaction { get { return Guid.NewGuid(); } }
        public DateTime DtTransaction { get; set; }
        public long AccountNumberDebit { get; set; }
        public long AccountNumberCredit { get; set; }
        public decimal Value { get; set; }

        public decimal BalanceAccountDebit { get; set; }

        public decimal BalanceAccountCredit { get; set; }




        public FluentValidation.Results.ValidationResult ValidBankLaunch(BankLaunch bankLaunch)
        {
            var validation = new BankLaunchValidator();

            return validation.Validation(validation, bankLaunch);
        }
    }
}
