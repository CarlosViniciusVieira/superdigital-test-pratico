﻿using SuperDigital.DomainDrivenDesign.Infrastructure.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain.Entities
{
    public class BaseEntity
    {
        public List<ErrorResponse> Errors { get; set; }

    }
}
