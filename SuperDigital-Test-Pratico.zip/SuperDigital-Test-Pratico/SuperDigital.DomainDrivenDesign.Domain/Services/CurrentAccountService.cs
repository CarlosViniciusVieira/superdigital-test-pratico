﻿using SuperDigital.DomainDrivenDesign.Domain.Entities;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Repository;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Services;
using SuperDigital.DomainDrivenDesign.Domain.Services.Validators;
using SuperDigital.DomainDrivenDesign.Infrastructure.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain.Services
{
    public class CurrentAccountService : ICurrentAccountService
    {

        private readonly ICurrentAccountRepository _currentAccountRepository;

        public CurrentAccountService(ICurrentAccountRepository currentAccountRepository)
        {
            _currentAccountRepository = currentAccountRepository;
        }


        public CurrentAccount GetCurrentAccount(long accountNumber)
        {
            return _currentAccountRepository.GetCurrentAccount(accountNumber);
        }

        public decimal DebitGenerate(long accountNumber, decimal value)
        {

            var accountDebit = GetCurrentAccount(accountNumber);

            _currentAccountRepository.UpdateBalance(accountNumber, (accountDebit.Balance - value));

            return (accountDebit.Balance - value);
        }

        public decimal CreditGenerate(long accountNumber, decimal value)
        {
            var accountCredit = GetCurrentAccount(accountNumber);


            _currentAccountRepository.UpdateBalance(accountNumber, (accountCredit.Balance + value));

            return (accountCredit.Balance + value);
        }



        public List<ErrorResponse> ValidationCurrentAccount(long accountNumberDebit, long accountNumberCredit)
        {
            CurrentAccountValidator validation = new CurrentAccountValidator(_currentAccountRepository, accountNumberDebit, accountNumberCredit);

            List<ErrorResponse> errors = new List<ErrorResponse>();
            var valid = validation.Validation(validation, new CurrentAccount());
            if (!valid.IsValid)
                foreach (var item in valid.Errors)
                    errors.Add(new ErrorResponse { Message = item.ErrorMessage, Code = item.GetHashCode() });


            return errors;
        }

    }
}
