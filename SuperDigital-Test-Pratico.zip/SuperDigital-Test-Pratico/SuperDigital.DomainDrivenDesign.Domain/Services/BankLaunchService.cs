﻿using SuperDigital.DomainDrivenDesign.Domain.Entities;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Repository;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Services;
using SuperDigital.DomainDrivenDesign.Infrastructure.CrossCutting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace SuperDigital.DomainDrivenDesign.Domain.Services
{
    public class BankLaunchService : IBankLaunchService
    {
        private readonly IBankLaunchRepository _bankLaunchRepository;

        private readonly ICurrentAccountService _currentAccountService;




        public BankLaunchService(IBankLaunchRepository bankLaunchRepository, ICurrentAccountService currentAccountService)
        {
            _bankLaunchRepository = bankLaunchRepository;
            _currentAccountService = currentAccountService;
        }


        public bool OperationGenerate(BankLaunch bankLaunch)
        {
            if (!Validation(bankLaunch))
                return false;


            TransactionGenerate(bankLaunch);

            _bankLaunchRepository.SaveTransactionBankLaunch(bankLaunch);

            return bankLaunch.Errors.Any();
        }

        private void TransactionGenerate(BankLaunch bankLaunch)
        {
            bankLaunch.Errors = _currentAccountService.ValidationCurrentAccount(bankLaunch.AccountNumberDebit, bankLaunch.AccountNumberCredit);

            if (!bankLaunch.Errors.Any())
            {
                bankLaunch.BalanceAccountDebit = _currentAccountService.DebitGenerate(bankLaunch.AccountNumberDebit, bankLaunch.Value);

                bankLaunch.BalanceAccountCredit = _currentAccountService.CreditGenerate(bankLaunch.AccountNumberCredit, bankLaunch.Value);
            }

        }

        private bool Validation(BankLaunch bankLaunch)
        {
            var valid = bankLaunch.ValidBankLaunch(bankLaunch);
            if (!valid.IsValid)
            {
                bankLaunch.Errors = new List<ErrorResponse>();

                foreach (var item in valid.Errors)
                    bankLaunch.Errors.Add(new ErrorResponse { Message = item.ErrorMessage, Code = item.GetHashCode() });


                return false;
            }

            return true;
        }


    }
}
;