﻿using FluentValidation;
using SuperDigital.DomainDrivenDesign.Domain.Entities;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain.Services.Validators
{
    public class CurrentAccountValidator : AbstractValidator<CurrentAccount>
    {
        public CurrentAccountValidator(ICurrentAccountRepository currentAccountRepository, long accountNumberDebit, long accountNumberCredit)
        {
            RuleFor(transaction => transaction)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .Custom((transfer, context) =>
                {
                    var accountDebit = currentAccountRepository.GetCurrentAccount(accountNumberDebit);
                    var accountCredit = currentAccountRepository.GetCurrentAccount(accountNumberCredit);


                    if (accountDebit == null)
                        context.AddFailure($"Não foi encontrado a conta corrente (ORIGEM) {accountNumberDebit}.");

                    if (accountCredit == null)
                        context.AddFailure($"Não foi encontrado a conta corrente (DESTINO) {accountNumberCredit}.");
                });
        }



        public FluentValidation.Results.ValidationResult Validation(CurrentAccountValidator validation, CurrentAccount request)
        {
            var result = validation.Validate(request);

            return result;
        }
    }
}