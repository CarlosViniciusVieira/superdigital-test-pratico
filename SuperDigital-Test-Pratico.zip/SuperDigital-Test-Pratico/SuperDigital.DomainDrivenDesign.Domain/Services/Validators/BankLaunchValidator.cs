﻿using FluentValidation;
using SuperDigital.DomainDrivenDesign.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain.Services.Validators
{
    public class BankLaunchValidator : AbstractValidator<BankLaunch>
    {

        public BankLaunchValidator()
        {
            RuleFor(bankLaunch => bankLaunch.AccountNumberDebit)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty()
                .NotNull()
                .Must(number => number > 0)
                .WithMessage("Número da conta de origem inválida");


            RuleFor(bankLaunch => bankLaunch.AccountNumberCredit)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty()
                .NotNull()
                .Must(number => number > 0)
                .WithMessage("Número da conta de destino inválida");

            RuleFor(transaction => transaction.Value)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty()
                .NotNull()
                .Must(number => number > 0)
                .WithMessage("Valor  tem que ser maior que 0.");

        }

        public FluentValidation.Results.ValidationResult Validation(BankLaunchValidator validation, BankLaunch request)
        {
            var result = validation.Validate(request);

            return result;
        }
    }
}
