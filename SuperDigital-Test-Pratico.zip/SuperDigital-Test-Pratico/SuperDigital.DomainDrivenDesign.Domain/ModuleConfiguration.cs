﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Domain
{
    public class ModuleConfiguration
    {
        public static string ConnectionString { get; set; }
    }
}
