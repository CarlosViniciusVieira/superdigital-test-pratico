﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Infrastructure.CrossCutting.Enumerator
{
    public class Enum
    {
        public enum BankLaunchType
        {
            DebitoEmConta = 1,
            CréditoEmConta = 2
        }
    }
}
