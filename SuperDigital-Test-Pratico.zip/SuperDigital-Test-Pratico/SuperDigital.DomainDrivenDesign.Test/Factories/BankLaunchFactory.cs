﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Test.Factories
{
    public static class BankLaunchFactory
    {

    }
}
