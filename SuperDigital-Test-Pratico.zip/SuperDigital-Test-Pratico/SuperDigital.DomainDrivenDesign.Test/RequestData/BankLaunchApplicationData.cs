﻿using SuperDigital.DomainDrivenDesign.Application.Models.Request;
using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.DomainDrivenDesign.Test.RequestData
{
    public static class BankLaunchApplicationData
    {
        public static TransactionRequest existingCurrentAccount = new TransactionRequest()
        {
            DestinationAccountNumber = 12345678,
            OriginAccountNumber = 87654321,
            Value = 400
        };

        public static TransactionRequest existingCurrentAccountInverse = new TransactionRequest()
        {
            DestinationAccountNumber = 87654321,
            OriginAccountNumber = 12345678,
            Value = 100
        };

        public static TransactionRequest transactionValueNull = new TransactionRequest()
        {
            DestinationAccountNumber = 12345678,
            OriginAccountNumber = 87654321,
            Value = 0
        };

        public static TransactionRequest transactionCurrentAccountNull = new TransactionRequest()
        {
            DestinationAccountNumber = 0,
            OriginAccountNumber = 0,
            Value = 400
        };


        public static TransactionRequest transactionCurrentAccountInvalid = new TransactionRequest()
        {
            DestinationAccountNumber = 22222222222,
            OriginAccountNumber = 1111111111111,
            Value = 400
        };
    }
}
