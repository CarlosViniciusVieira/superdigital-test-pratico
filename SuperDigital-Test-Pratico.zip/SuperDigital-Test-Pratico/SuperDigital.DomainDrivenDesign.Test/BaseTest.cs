using SuperDigital.DomainDrivenDesign.Test.RequestData;
using System.Collections.Generic;

namespace SuperDigital.DomainDrivenDesign.Test
{
    public class BaseTest
    {
        public BaseTest() { }



        public static IEnumerable<object[]> GetCasesTransactionValid()
        {
            yield return new object[] { BankLaunchApplicationData.existingCurrentAccount };
            yield return new object[] { BankLaunchApplicationData.existingCurrentAccountInverse };
        }

        public static IEnumerable<object[]> GetCasesTransactionInvalid()
        {
            yield return new object[] { BankLaunchApplicationData.transactionValueNull };
            yield return new object[] { BankLaunchApplicationData.transactionCurrentAccountNull };
            yield return new object[] { BankLaunchApplicationData.transactionCurrentAccountInvalid };
        }

    }
}
