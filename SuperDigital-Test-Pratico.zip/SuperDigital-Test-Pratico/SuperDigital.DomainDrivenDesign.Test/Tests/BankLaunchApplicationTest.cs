﻿using SuperDigital.DomainDrivenDesign.Application.Application;
using SuperDigital.DomainDrivenDesign.Application.Interface;
using SuperDigital.DomainDrivenDesign.Application.Models.Request;
using SuperDigital.DomainDrivenDesign.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace SuperDigital.DomainDrivenDesign.Test.Tests
{
    public class BankLaunchApplicationTest : BaseTest
    {
        private readonly IBankLaunchApplication _application;

        public BankLaunchApplicationTest(IBankLaunchApplication application)
        {
            _application = application;
        }


        [Theory, MemberData(nameof(GetCasesTransactionValid))]
        public void BankLaunchTestValid(TransactionRequest request)
        {
            var result = _application.OperationGenerate(request);
            Assert.True(result.Success);
        }

        [Theory, MemberData(nameof(GetCasesTransactionInvalid))]
        public void BankLaunchTestInValid(TransactionRequest request)
        {
            var result = _application.OperationGenerate(request);
            Assert.False(result.Success);
        }
    }
}
